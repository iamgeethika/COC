import unittest
import points
from king import King
from village import Village
from buildings import Hut

class KingAttack_Test(unittest.TestCase):
    def setUp(self):
        #for each testcase => creates a new king
        self.king = King([2,4])
        self.V = Village(points.config_level_1, level=1)
        self.hut = self.V.hut_objs[self.V.huts[0]]

    #Tests whether the king is attacking the hut
    def test_attack(self):
        self.king.attack_target(self.hut,self.king.attack)
        self.assertEqual(self.hut.health, self.hut.max_health - self.king.attack)
        self.assertEqual(self.hut.destroyed, False)

    


suite = unittest.TestLoader().loadTestsFromTestCase(KingMovement_Test)
result = unittest.TextTestRunner(verbosity=0).run(suite)

f =open("./output_bonus.txt","w")

if(result.wasSuccessful()):
    f.write("True")
    f.close()

else:
    f.write("False")
    f.close()
