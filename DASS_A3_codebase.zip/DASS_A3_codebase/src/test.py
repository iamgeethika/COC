import unittest
import points
from king import King
from village import Village


class KingMovement_Test(unittest.TestCase):
    def setUp(self):
        #for each testcase => creates a new king
        self.king = King([2,4])
        self.V = Village(points.config_level_1, level=1)


    # Tests whether the king is moving in the up direction correctly
    def test_up(self):
        self.king.position=[2,4]
        stepsize = self.king.speed
        self.king.move('up',self.V)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,2-stepsize)
        self.assertEqual(coordinate2,4)

    # Tests whether the king is moving in the down direction correctly
    def test_down(self):
        self.king.position=[2,4]
        stepsize = self.king.speed
        self.king.move('down',self.V)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,2+stepsize)
        self.assertEqual(coordinate2,4)

    # Tests whether the king is moving in the left direction correctly
    def test_left(self):
        self.king.position=[2,4]
        stepsize = self.king.speed
        self.king.move('left',self.V)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,2)
        self.assertEqual(coordinate2,4-stepsize)

    # Tests whether the king is moving in the right direction correctly
    def test_right(self):
        self.king.position=[2,4]
        stepsize = self.king.speed
        self.king.move('right',self.V)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,2)
        self.assertEqual(coordinate2,4+stepsize)

    #Tests when the king cant move up
    def test_when_cant_move_up(self):
        self.king.position=[0,4]
        stepsize = self.king.speed
        self.king.move('up',self.V)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,0)
        self.assertEqual(coordinate2,4)

    #Tests when the king cant move left
    def test_when_cant_move_left(self):
        self.king.position=[2,0]
        stepsize = self.king.speed
        self.king.move('left',self.V)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,2)
        self.assertEqual(coordinate2,0)

    #Tests when the king cant move down
    def test_when_cant_move_down(self):
        self.king.position = [len(self.V.map)-1, 4]
        stepsize = self.king.speed
        self.king.move('down',self.V)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,len(self.V.map)-1)
        self.assertEqual(coordinate2,4)

    #Tests when the king cant move right
    def test_when_cant_move_right(self):
        self.king.position = [2, len(self.V.map[0])-1]
        stepsize = self.king.speed
        self.king.move('right',self.V)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,2)
        self.assertEqual(coordinate2,len(self.V.map[0])-1)

    
    #Tests when the king cant move at corners

    #Tests when the king cant move at left up corner
    def test_when_cant_move_leftup(self):
        self.king.position=[0,0]
        stepsize = self.king.speed
        self.king.move('up',self.V)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,0)
        self.assertEqual(coordinate2,0)


        self.king.position=[0,0]
        stepsize = self.king.speed
        self.king.move('left',self.V)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,0)
        self.assertEqual(coordinate2,0)

    #Tests when the king cant move at left down corner
    def test_when_cant_move_leftdown(self):
        self.king.position = [len(self.V.map)-1, 0]
        stepsize = self.king.speed
        self.king.move('down',self.V)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,len(self.V.map)-1)
        self.assertEqual(coordinate2,0)


        self.king.position = [len(self.V.map)-1, 0]
        stepsize = self.king.speed
        self.king.move('left',self.V)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,len(self.V.map)-1)
        self.assertEqual(coordinate2,0)
    
    #Tests when the king cant move at right up corner
    def test_when_cant_move_rightup(self):
        self.king.position=[0,len(self.V.map[0])-1]
        stepsize = self.king.speed
        self.king.move('up',self.V)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,0)
        self.assertEqual(coordinate2,len(self.V.map[0])-1)


        self.king.position=[0,len(self.V.map[0])-1]
        stepsize = self.king.speed
        self.king.move('right',self.V)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,0)
        self.assertEqual(coordinate2,len(self.V.map[0])-1)

    #Tests when the king cant move at right down corner
    def test_when_cant_move_rightdown(self):
        self.king.position=[len(self.V.map)-1,len(self.V.map[0])-1]
        stepsize = self.king.speed
        self.king.move('down',self.V)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,len(self.V.map)-1)
        self.assertEqual(coordinate2,len(self.V.map[0])-1)


        self.king.position=[len(self.V.map)-1,len(self.V.map[0])-1]
        stepsize = self.king.speed
        self.king.move('right',self.V)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,len(self.V.map)-1)
        self.assertEqual(coordinate2,len(self.V.map[0])-1)

    #Tests when the king is dead => it shouldn't move

    def test_dead_king_up(self):
        self.king.alive=False
        self.king.position=[2,4]
        stepsize = self.king.speed
        self.king.move('up',self.V)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,2)
        self.assertEqual(coordinate2,4)

    def test_dead_king_down(self):
        self.king.alive=False
        self.king.position=[2,4]
        stepsize = self.king.speed
        self.king.move('down',self.V)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,2)
        self.assertEqual(coordinate2,4)

    def test_dead_king_left(self):
        self.king.alive=False
        self.king.position=[2,4]
        stepsize = self.king.speed
        self.king.move('left',self.V)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,2)
        self.assertEqual(coordinate2,4)

    def test_dead_king_right(self):
        self.king.alive=False
        self.king.position=[2,4]
        stepsize = self.king.speed
        self.king.move('right',self.V)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,2)
        self.assertEqual(coordinate2,4)

    def test_obstacle_up(self):
        #There is an obstacle at [3,9] => so if our king is at [2,9] he cant move up
        self.king.position = [2,9]
        self.V = Village(points.config_level_1, level=1)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,2)
        self.assertEqual(coordinate2,9)

    def test_obstacle_down(self):
        #There is an obstacle at [11,5] => so if our king is at [12,5] he cant move down
        self.king.position = [12,5]
        self.V = Village(points.config_level_1, level=1)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,12)
        self.assertEqual(coordinate2,5)

    def test_obstacle_left(self):
        #There is an obstacle at [11,5] => so if our king is at [11,6] he cant move left
        self.king.position = [11,6]
        self.V = Village(points.config_level_1, level=1)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,11)
        self.assertEqual(coordinate2,6)

    def test_obstacle_right(self):
        #There is an obstacle at [3,9] => so if our king is at [3,8] he cant move right
        self.king.position = [3,8]
        self.V = Village(points.config_level_1, level=1)
        coordinate1 = self.king.position[0]
        coordinate2 = self.king.position[1]
        self.assertEqual(coordinate1,3)
        self.assertEqual(coordinate2,8)

    

suite = unittest.TestLoader().loadTestsFromTestCase(KingMovement_Test)
result = unittest.TextTestRunner(verbosity=0).run(suite)

f =open("./output.txt","w")

if(result.wasSuccessful()):
    f.write("True")
    f.close()

else:
    f.write("False")
    f.close()


