# Assignment 4

## Assumptions
1. I have written the testcases assuming that all the functions in the code remains the same except move and attack_target functions
2. The test cases are based on the level map 1
3. "output.txt" is formed in which the program is being executed

## Test Cases for move function .. King.move()

1. ### test_up:
    The function checks if the king moves up correctly or not
    * #### Expected behaviour : The position of the king should move in the upward direction
2. ### test_down:
    The function checks if the king moves down correctly or not
    * #### Expected behaviour : The position of the king should move in the downward direction
3. ### test_left:
    The function checks if the king moves left correctly or not
    * #### Expected behaviour : The position of the king should move in the left direction
4. ### test_right:
    The function checks if the king moves right correctly or not
    * #### Expected behaviour : The position of the king should move in the right direction
5. ### test_when_cant_move_up:
    The function checks if the king moves up where it cant
    * #### Expected behaviour : The position of the king should stop when it cant move up
6. ### test_when_cant_move_down:
    The function checks if the king moves down where it cant
    * #### Expected behaviour : The position of the king should stop when it cant move down
7. ### test_when_cant_move_left:
    The function checks if the king moves left where it cant
    * #### Expected behaviour : The position of the king should stop when it cant move left
8. ### test_when_cant_move_right:
    The function checks if the king moves right where it cant
    * #### Expected behaviour : The position of the king should stop when it cant move right
9. ### test_when_cant_move_leftup:
    The function checks if the king moves left or up when it cant
    * #### Expected behaviour : The position of the king should not change
10. ### test_when_cant_move_leftdown:
    The function checks if the king moves left or down when it cant
    * #### Expected behaviour : The position of the king should not change
11. ### test_when_cant_move_righup:
    The function checks if the king moves right or up when it cant
    * #### Expected behaviour : The position of the king should not change
12. ### test_when_cant_move_rightdown:
    The function checks if the king moves right or down when it cant
    * #### Expected behaviour : The position of the king should not change
13. ### test_dead_king_up:
    The function checks when the king is dead whether it is moving up or not
    * #### Expected behaviour : The position of the dead king should not change
14. ### test_dead_king_down:
    The function checks when the king is dead whether it is moving down or not
    * #### Expected behaviour : The position of the dead king should not change
15. ### test_dead_king_left:
    The function checks when the king is dead whether it is moving left or not
    * #### Expected behaviour : The position of the dead king should not change
16. ### test_dead_king_right:
    The function checks when the king is dead whether it is moving right or not
    * #### Expected behaviour : The position of the dead king should not change
17. ### test_obstacle_up:
    The function checks when there is an obstacle, whether it is passing through the obstacle or not
    * #### Expected behaviour : The position of the king should not change
18. ### test_obstacle_down:
    The function checks when there is an obstacle, whether it is passing through the obstacle or not
    * #### Expected behaviour : The position of the king should not change
19. ### test_obstacle_right:
    The function checks when there is an obstacle, whether it is passing through the obstacle or not
    * #### Expected behaviour : The position of the king should not change
20. ### test_obstacle_left:
    The function checks when there is an obstacle, whether it is passing through the obstacle or not
    * #### Expected behaviour : The position of the king should not change